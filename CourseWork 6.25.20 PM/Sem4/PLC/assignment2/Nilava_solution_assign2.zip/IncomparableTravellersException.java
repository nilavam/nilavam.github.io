class IncomparableTravellersException extends Exception
{
	public IncomparableTravellersException(String msg)
	{
		super(msg);
	}
}