interface Vehicle
{
	public int getCapacity();
}