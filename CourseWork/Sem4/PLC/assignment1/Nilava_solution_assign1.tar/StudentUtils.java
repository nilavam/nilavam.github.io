class StudentUtils
{
	public static void maleThreePerRoom(Student[] students)
	{
		int n = students.length;
		for (int i = 0; i < n; i++)
		{
			if ((students[i].getRoommateCount() == 2) && (students[i].get_gender()).equals("male"))
				System.out.println(students[i].get_name());
		}
	}

	public static void cgpaAtLeast(CourseStudent[] students, int minCgpa)
	{
		int n = students.length;
		for (int i = 0; i < n; i++)
		{
			if (students[i].get_cgpa() >= minCgpa)
				System.out.println(students[i].get_name());
		}
	}
}