abstract class Student
{
	private String name, gender, program;
	private int age;

	//name accessor
	public String get_name()
	{
		return name;
	}

	//name mutator
	public void set_name(String new_name)
	{
		this.name = new_name;
	}

	//gender accessor
	public String get_gender()
	{
		return gender;
	}

	//gender mutator
	public void set_gender(String new_gender)
	{
		this.gender = new_gender;
	}

	//program accessor
	public String get_program()
	{
		return program;
	}

	//program mutator
	public void set_program(String new_program)
	{
		this.program = new_program;
	}

	//age accessor
	public int get_age()
	{
		return age;
	}

	//age mutator
	public void set_age(int new_age)
	{
		this.age = new_age;
	}

	public abstract int getRoommateCount();
}