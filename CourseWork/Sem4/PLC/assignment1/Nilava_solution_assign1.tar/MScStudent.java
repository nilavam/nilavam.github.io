class MScStudent extends CourseStudent
{
	private final static int rm = 1;
	
	//parameterized constructor
	public MScStudent(String n, int a, String g, String p, int c, int b)
	{
		set_name(n);
		set_age(a);
		set_gender(g);
		set_program(p);
		set_cgpa(c);
		set_backlogs(b);
	}

	//method to get number of roommates
	public int getRoommateCount()
	{
		return rm;
	}
}