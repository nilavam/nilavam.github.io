class PhDStudent extends Student
{
	private String advisor;
	private final static int rm = 0;

	//parameterized constructor
	public PhDStudent(String n, int a, String g, String p, String adv)
	{
		set_name(n);
		set_age(a);
		set_gender(g);
		set_program(p);
		advisor = adv;
	}

	//advisor accessor
	public String get_advisor()
	{
		return advisor;	
	}

	//advisor mutator
	public void set_advisor(String new_advisor)
	{
		advisor = new_advisor;
	}

	//method to get number of roommates
	public int  getRoommateCount()
	{
		return rm;
	}
}