abstract class CourseStudent extends Student
{
	private int cgpa, backlogs;

	//cgpa accessor
	public int get_cgpa()
	{
		return cgpa;
	}

	//cgpa mutator
	public void set_cgpa(int new_cgpa)
	{
		this.cgpa = new_cgpa;
	}

	//backlogs accessor
	public int get_backlogs()
	{
		return backlogs;
	}

	//backlogs mutator
	public void set_backlogs(int new_backlogs)
	{
		this.backlogs = new_backlogs;
	}
}